-- 계정 생성 및 권한 부여
CREATE USER medipaw IDENTIFIED BY 1111; 
GRANT RESOURCE, CREATE SESSION TO medipaw;

-- 테이블 생성
