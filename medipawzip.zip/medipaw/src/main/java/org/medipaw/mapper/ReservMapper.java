package org.medipaw.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.medipaw.domain.Criteria;
import org.medipaw.domain.ReservVO;
import org.medipaw.domain.SiljongVO;

public interface ReservMapper {
	public List<ReservVO> selectAllPagingUser(@Param("id") String id, @Param("cri") Criteria cri);
	public List<ReservVO> selectAllPagingStaff(@Param("hosNo") int hosNo, @Param("cri") Criteria cri);
	public List<ReservVO> selectAllPagingAdm(Criteria cri);
	public ReservVO select(int rno);
	public int insert(ReservVO rvo);			
	public int delete(int rno);
	public int update(ReservVO rvo);
}
