package org.medipaw.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import org.medipaw.domain.Criteria;
import org.medipaw.domain.ReservVO;
import org.medipaw.domain.TreatVO;
import org.medipaw.service.ReservService;
import org.medipaw.service.SiljongService;
import org.medipaw.service.TreatService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Controller
@Log4j
@RequestMapping("/treat/*")
@AllArgsConstructor
public class TreatController {
	private TreatService tService;
	
	@PostMapping("register")	
	@PreAuthorize("isAuthenticated()")
	public String register(TreatVO tvo, RedirectAttributes rttr) {		// BoardControllerTests에서 돌려보기
//		log.info("registerController...");
//		
//		if(bvo.getAttachList() != null) {								// 첨부파일 들어가는 list log로 보기
//			bvo.getAttachList().forEach(attach -> log.info(attach));
//		}
//		
//		if(boardService.register(bvo)) {
//			rttr.addFlashAttribute("result", bvo.getBno());
//		}
//		// 반환이 void면 /WEB-INF/views/board/list.jsp로 이동하는데 jsp로 가면 안되고 맵핑된 list로 가야함
		return "redirect:/board/list";
//		// 얘는 @GetMapping("list")로 이동! -> select된 목록을 갖고 가야하므로 .do로 보내는 것과 동일
	}
	
	@GetMapping("register")
	@PreAuthorize("isAuthenticated()")
	public void register() {
		log.info("register.jsp...");
	}
	
	@GetMapping({"view", "modify"})		// 원래는 view 컨트롤러였는데 수정하기 전에 수정 폼에서 view처리 해야하므로 묶음
	public void view(Model model, int tno, @ModelAttribute("cri") Criteria cri) {	// cri를 view.jsp로 넘겨야함
//		log.info("viewController....");
//		model.addAttribute("view", boardService.view(bno));
	}
	
	@PostMapping("modify")
	@PreAuthorize("principal.username == #bvo.writer")		// modify.jsp의 값들이 넘어와서 그대로 비교
	public String modify(TreatVO tvo, RedirectAttributes rttr, @ModelAttribute("cri") Criteria cri) {		// BoardControllerTests에서 돌려보기
//		log.info("modifyController...");
//		
//		if(boardService.modify(bvo)) {
//			rttr.addFlashAttribute("result", "success");	// modify가 성공적으로 되면 result에 success 담아서 보내
//		};
//		// redirect는 reponse 객체 사용하는데 @ModelAttribute는 request 객체를 사용해서 결과 페이지까지 못 감
//		// 그래서 rttr 사용해서 attribute에 담아서 보냄
//		rttr.addAttribute("amount", cri.getAmount());	
//		rttr.addAttribute("pageNum", cri.getPageNum());
//		rttr.addAttribute("type", cri.getType());	
//		rttr.addAttribute("keyword", cri.getKeyword());
//		// 반환이 void면 /WEB-INF/views/board/list.jsp로 이동하는데 jsp로 가면 안되고 맵핑된 list로 가야함
		return "redirect:/board/list";
//		// 얘는 @GetMapping("list")로 이동! -> select된 목록을 갖고 가야하므로 .do로 보내는 것과 동일
	}
	
	@PostMapping("remove")
	@PreAuthorize("principal.username == #writer")
	public String remove(int tno, RedirectAttributes rttr, @ModelAttribute("cri") Criteria cri) {		// BoardControllerTests에서 돌려보기
//		log.info("removeController...");
//		
//		List<BoardAttachVO> attachList = boardService.attachList(bno);  // 해당 게시글의 첨부 파일 목록 가져오기
//		
//		if(boardService.remove(bno)) {
//			deleteFiles(attachList);									// 첨부 파일 삭제 메서드 호출
//			rttr.addFlashAttribute("result", "success");
//		}
//		rttr.addAttribute("amount", cri.getAmount());	
//		rttr.addAttribute("pageNum", cri.getPageNum());
//		rttr.addAttribute("type", cri.getType());	
//		rttr.addAttribute("keyword", cri.getKeyword());
//		// 반환이 void면 /WEB-INF/views/board/list.jsp로 이동하는데 jsp로 가면 안되고 맵핑된 list로 가야함
		return "redirect:/board/list";
//		// 얘는 @GetMapping("list")로 이동! -> select된 목록을 갖고 가야하므로 .do로 보내는 것과 동일
	}
	
	@GetMapping("listUser")					
	public void listUser(Model model, String id, Criteria cri) {		// BoardControllerTests에서 돌려보기
//		log.info("listController..." + cri);
//		model.addAttribute("pageDTO", new PageDTO(cri, boardService.totalCount(cri)));
//		model.addAttribute("list", boardService.listPaging(cri));
	}
	
	@GetMapping("listStaff")					
	public void listStaff(Model model, int hosNo, Criteria cri) {		// BoardControllerTests에서 돌려보기
//		log.info("listController..." + cri);
//		model.addAttribute("pageDTO", new PageDTO(cri, boardService.totalCount(cri)));
//		model.addAttribute("list", boardService.listPaging(cri));
	}
	
	@GetMapping("listAdm")					
	public void listAdm(Model model, Criteria cri) {		// BoardControllerTests에서 돌려보기
//		log.info("listController..." + cri);
//		model.addAttribute("pageDTO", new PageDTO(cri, boardService.totalCount(cri)));
//		model.addAttribute("list", boardService.listPaging(cri));
	}
	
}
