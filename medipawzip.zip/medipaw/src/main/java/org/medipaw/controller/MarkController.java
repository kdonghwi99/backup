package org.medipaw.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import org.medipaw.domain.Criteria;
import org.medipaw.domain.MarkVO;
import org.medipaw.domain.SiljongVO;
import org.medipaw.service.MarkService;
import org.medipaw.service.SiljongService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Controller
@Log4j
@RequestMapping("/mark/*")
@AllArgsConstructor
public class MarkController {
	private MarkService mService;
	
	@PostMapping("register")	
	@PreAuthorize("isAuthenticated()")
	public String register(MarkVO mvo, RedirectAttributes rttr) {		// BoardControllerTests에서 돌려보기
//		log.info("registerController...");
//		
//		if(bvo.getAttachList() != null) {								// 첨부파일 들어가는 list log로 보기
//			bvo.getAttachList().forEach(attach -> log.info(attach));
//		}
//		
//		if(boardService.register(bvo)) {
//			rttr.addFlashAttribute("result", bvo.getBno());
//		}
//		// 반환이 void면 /WEB-INF/views/board/list.jsp로 이동하는데 jsp로 가면 안되고 맵핑된 list로 가야함
		return "redirect:/board/list";
//		// 얘는 @GetMapping("list")로 이동! -> select된 목록을 갖고 가야하므로 .do로 보내는 것과 동일
	}
	
	@PostMapping("remove")
	@PreAuthorize("principal.username == #writer")
	public String remove(int mno, RedirectAttributes rttr, @ModelAttribute("cri") Criteria cri) {		// BoardControllerTests에서 돌려보기
//		log.info("removeController...");
//		
//		List<BoardAttachVO> attachList = boardService.attachList(bno);  // 해당 게시글의 첨부 파일 목록 가져오기
//		
//		if(boardService.remove(bno)) {
//			deleteFiles(attachList);									// 첨부 파일 삭제 메서드 호출
//			rttr.addFlashAttribute("result", "success");
//		}
//		rttr.addAttribute("amount", cri.getAmount());	
//		rttr.addAttribute("pageNum", cri.getPageNum());
//		rttr.addAttribute("type", cri.getType());	
//		rttr.addAttribute("keyword", cri.getKeyword());
//		// 반환이 void면 /WEB-INF/views/board/list.jsp로 이동하는데 jsp로 가면 안되고 맵핑된 list로 가야함
		return "redirect:/board/list";
//		// 얘는 @GetMapping("list")로 이동! -> select된 목록을 갖고 가야하므로 .do로 보내는 것과 동일
	}
	
	@GetMapping("list")					
	public void list(String id, Model model, Criteria cri) {		// BoardControllerTests에서 돌려보기
//		log.info("listController..." + cri);
//		model.addAttribute("pageDTO", new PageDTO(cri, boardService.totalCount(cri)));
//		model.addAttribute("list", boardService.listPaging(cri));
	}
	
}
