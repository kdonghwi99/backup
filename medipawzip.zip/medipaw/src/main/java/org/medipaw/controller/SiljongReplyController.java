package org.medipaw.controller;

import java.util.List;

import javax.print.attribute.standard.Media;

import org.medipaw.domain.SiljongReplyPageDTO;
import org.medipaw.domain.SiljongReplyVO;
import org.medipaw.domain.SiljongVO;
import org.medipaw.service.SiljongReplyService;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.medipaw.domain.Criteria;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@RestController					// JSON 사용하면 @RestController 사용 -> @Controller 안돼!!!
@Log4j
@RequestMapping("/replies/")
@AllArgsConstructor
public class SiljongReplyController {
	private SiljongReplyService sjrService;
	
	
	// 댓글 목록 및 200번 상태 코드 반환
	@GetMapping(value="pages/{sjno}/{pageNum}")			// url : /replies/pages/:bno/:pageNum으로 갈겨!				
	public ResponseEntity<SiljongReplyPageDTO> list(@PathVariable("sjno") int sjno, @PathVariable("pageNum") int pageNum) {		
		log.info("listController...");
		Criteria cri = new Criteria(3, pageNum);
		return new ResponseEntity<SiljongReplyPageDTO>(sjrService.listPaging(sjno, cri), HttpStatus.OK);
	}
	
	// JSON으로 댓글 등록
	@PostMapping(value="add", produces=MediaType.TEXT_PLAIN_VALUE)	
	@PreAuthorize("isAuthenticated()")
	public ResponseEntity<String> add(@RequestBody SiljongReplyVO sjrvo) {		
		log.info("addController...");
		if(sjrService.add(sjrvo)) {
			// 등록 성공이면 200과 success 보내고
			return new ResponseEntity<>("success", HttpStatus.OK);
		} else {
			// 실패하면 500 상태코드 반환
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	// 댓글 1개 및 200번 상태 코드 반환
	@GetMapping(value="{sjrno}")			// url : /replies/:rno로 갈겨!				
	public ResponseEntity<SiljongReplyVO> view(@PathVariable("sjrno") int sjrno) {		
		log.info("viewController...");
		return new ResponseEntity<SiljongReplyVO>(sjrService.view(sjrno), HttpStatus.OK);
	}
		
//	@GetMapping({"view", "modify"})		// 원래는 view 컨트롤러였는데 수정하기 전에 수정 폼에서 view처리 해야하므로 묶음
//	public void view(Model model, int rno, @ModelAttribute("cri") Criteria cri) {	// cri를 view.jsp로 넘겨야함
//		log.info("viewController....");
//		model.addAttribute("view", replyService.view(rno));
//	}
	
	// JSON으로 댓글 수정
	@RequestMapping(value="{sjrno}", produces=MediaType.TEXT_PLAIN_VALUE, 
					method = {RequestMethod.PUT, RequestMethod.PATCH})		
	public ResponseEntity<String> modify(@RequestBody SiljongReplyVO sjrvo, @PathVariable("sjrno") int sjrno) {		
		log.info("modifyController...");
		if(sjrService.modify(sjrvo)) {
			// 수정 성공이면 200과 success 보내고
			return new ResponseEntity<>("success", HttpStatus.OK);
		} else {
			// 실패하면 500 상태코드 반환
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	// JSON으로 댓글 삭제
	@DeleteMapping(value="{sjrno}", produces="text/plain; charset=UTF-8")		
	public ResponseEntity<String> remove(String writer, @PathVariable("sjrno") int sjrno) {		
		log.info("removeController...");
		if(sjrService.remove(sjrno)) {
			// 삭제 성공이면 200과 success 보내고
			return new ResponseEntity<>("success", HttpStatus.OK);
		} else {
			// 실패하면 500 상태코드 반환
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
