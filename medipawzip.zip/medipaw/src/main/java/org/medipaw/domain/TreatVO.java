package org.medipaw.domain;

import java.util.Date;
import lombok.Data;

@Data
public class TreatVO {
	// 예약한 병원, 병원 주소, 병원 전화번호, 예약자 이름, 진료 일자, 진료 시간, 진료 내용
	private int tno;
	private int rvno;
	private int hno;
	private String id;
//	private String hosName;		// 병원 내용은 병원 VO에 있으니까 빼도 됨
//	private String hosAddr;		
//	private String hosTel;
//	private String treatPerson;	// 예약 번호(pk)만 있으면 될거같음
	private Date   tDate;
	private String tTime;
	private String tNote;	
}
