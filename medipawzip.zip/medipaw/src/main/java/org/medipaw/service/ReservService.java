package org.medipaw.service;

import java.util.List;

import org.medipaw.domain.Criteria;
import org.medipaw.domain.ReservVO;

public interface ReservService {
	public ReservVO view(int rno);
	public boolean register(ReservVO rvo);	
	public boolean remove(int rno);
	public boolean modify(ReservVO rvo);
	public List<ReservVO> listPagingAdm(Criteria cri);
	public List<ReservVO> listPagingUser(String id, Criteria cri);
	public List<ReservVO> listPagingStaff(int hosNo, Criteria cri);
}
