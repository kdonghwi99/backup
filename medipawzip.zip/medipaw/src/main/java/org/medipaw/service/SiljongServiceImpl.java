package org.medipaw.service;

import java.util.List;

import org.medipaw.domain.Criteria;
import org.medipaw.domain.SiljongAttachVO;
import org.medipaw.domain.SiljongVO;
import org.medipaw.mapper.SiljongAttachMapper;
import org.medipaw.mapper.SiljongMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.Setter;

@Service
public class SiljongServiceImpl implements SiljongService {
	@Setter(onMethod_ = @Autowired)		
	private SiljongMapper sjMapper;
	@Setter(onMethod_ = @Autowired)		
	private SiljongAttachMapper sjattMapper;

	@Override
	public SiljongVO view(int sjno) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean register(SiljongVO sjvo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean remove(int sjno) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean modify(SiljongVO sjvo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<SiljongVO> listPaging(Criteria cri) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<SiljongVO> listMine(String id, Criteria cri) {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public int totalCount(Criteria cri) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<SiljongAttachVO> attachList(int sjno) {
		// TODO Auto-generated method stub
		return null;
	}

}
