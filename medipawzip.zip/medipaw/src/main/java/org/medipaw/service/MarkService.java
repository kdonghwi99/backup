package org.medipaw.service;

import java.util.List;

import org.medipaw.domain.Criteria;
import org.medipaw.domain.MarkVO;

public interface MarkService {
	public boolean register(MarkVO mvo);	
	public boolean remove(int mno);
	public List<MarkVO> list(String id, Criteria cri);
}
