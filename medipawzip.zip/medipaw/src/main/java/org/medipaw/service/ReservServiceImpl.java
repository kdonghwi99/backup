package org.medipaw.service;

import java.util.List;

import org.medipaw.domain.Criteria;
import org.medipaw.domain.ReservVO;
import org.medipaw.mapper.ReservMapper;
import org.medipaw.mapper.SiljongMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.Setter;

@Service
public class ReservServiceImpl implements ReservService {
	@Setter(onMethod_ = @Autowired)		
	private ReservMapper rMapper;
	
	@Override
	public ReservVO view(int rno) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean register(ReservVO rvo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean remove(int rno) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean modify(ReservVO rvo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<ReservVO> listPagingAdm(Criteria cri) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<ReservVO> listPagingUser(String id, Criteria cri) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<ReservVO> listPagingStaff(int hosNo, Criteria cri) {
		// TODO Auto-generated method stub
		return null;
	}

}
