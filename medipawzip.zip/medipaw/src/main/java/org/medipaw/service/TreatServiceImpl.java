package org.medipaw.service;

import java.util.List;

import org.medipaw.domain.Criteria;
import org.medipaw.domain.TreatVO;
import org.medipaw.mapper.ReservMapper;
import org.medipaw.mapper.TreatMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.Setter;

@Service
public class TreatServiceImpl implements TreatService {
	@Setter(onMethod_ = @Autowired)		
	private TreatMapper tMapper;
	
	@Override
	public TreatVO view(int tno) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean register(TreatVO tvo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean remove(int tno) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean modify(TreatVO tvo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<TreatVO> listPagingAdm(Criteria cri) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<TreatVO> listPagingUser(String id, Criteria cri) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<TreatVO> listPagingStaff(int hosNo, Criteria cri) {
		// TODO Auto-generated method stub
		return null;
	}

}
