package org.medipaw.service;

import org.medipaw.domain.Criteria;
import org.medipaw.domain.SiljongReplyPageDTO;
import org.medipaw.domain.SiljongReplyVO;
import org.medipaw.domain.SiljongVO;
import org.medipaw.mapper.SiljongMapper;
import org.medipaw.mapper.SiljongReplyMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.Setter;

@Service
public class SiljongReplyServiceImpl implements SiljongReplyService {
	@Setter(onMethod_ = @Autowired)		
	private SiljongMapper sjMapper;
	@Setter(onMethod_ = @Autowired)		
	private SiljongReplyMapper sjrMapper;
	
	@Override
	public boolean add(SiljongReplyVO sjrvo) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public SiljongReplyVO view(int sjrno) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public SiljongReplyPageDTO listPaging(int sjno, Criteria cri) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public boolean modify(SiljongReplyVO sjrvo) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public boolean remove(int sjrno) {
		// TODO Auto-generated method stub
		return false;
	}

}
