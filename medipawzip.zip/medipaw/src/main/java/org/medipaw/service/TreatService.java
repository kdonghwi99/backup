package org.medipaw.service;

import java.util.List;

import org.medipaw.domain.Criteria;
import org.medipaw.domain.ReservVO;
import org.medipaw.domain.TreatVO;

public interface TreatService {
	public TreatVO view(int tno);
	public boolean register(TreatVO tvo);	
	public boolean remove(int tno);
	public boolean modify(TreatVO tvo);
	public List<TreatVO> listPagingAdm(Criteria cri);
	public List<TreatVO> listPagingUser(String id, Criteria cri);
	public List<TreatVO> listPagingStaff(int hosNo, Criteria cri);
}
