package org.medipaw.service;

import java.util.List;

import org.medipaw.domain.Criteria;
import org.medipaw.domain.MarkVO;
import org.medipaw.domain.SiljongVO;
import org.medipaw.mapper.MarkMapper;
import org.medipaw.mapper.SiljongMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.Setter;

@Service
public class MarkServiceImpl implements MarkService {
	@Setter(onMethod_ = @Autowired)		
	private MarkMapper mMapper;

	@Override
	public boolean register(MarkVO mvo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean remove(int mno) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<MarkVO> list(String id, Criteria cri) {
		// 병원 가나다 순일 경우 selectHos 가져오고
		// 등록 최신 순일 경우 selectMno 가져오기
		return null;
	}

}
